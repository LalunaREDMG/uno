<?php

return [
    'server_ip'=> env('AUTOPOLL_IP'),

    'tenant_code'=>env('TENANT_CODE'),

    'terminal_code'=>env('TERMINAL_CODE'),

    'pos_vendor_code'=>env('POS_VENDOR_CODE'),

    'model_platform_code'=>env('MODEL_PLATFORM_CODE'),

    'bearer_token'=>'dXh8WY2TsQsBBVd8WQvF2nsYL1_YLdolvzLUJRScV0wNTKdN7yRTFNxczUJmhCNQXk_4fpCEgM5K8KMWwdOweRQWGNoPG_XKQyio',
    
    'jwt_token'=>'eyJhbGciOiJIUzI1NiJ9.eyJSb2xlIjoiQWRtaW4iLCJJc3N1ZXIiOiJJc3N1ZXIiLCJVc2VybmFtZSI6IkphdmFJblVzZSIsImV4cCI6MTY1NDc1NDg1NCwiaWF0IjoxNjU0NzU0ODU0fQ.p6WAfLuC39cMk3XEF4LcU5iZy1rzbL0VTKVpTY7mRGQ',
];