<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStatusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d h:i:s');
        $curdate = date('Y-m-d');

        Schema::create('status', function (Blueprint $table) {
            $table->tinyInteger('id');
            $table->tinyInteger('connection_status');
            $table->tinyInteger('is_file');
            $table->tinyInteger('current_date');
            $table->timestamps();
        });
        DB::table('status')->insert([
            'id'=>1,
            'connection_status'=>0,
            'is_file'=>0,
            'current_date'=>$curdate,
            'created_at'=>$date,
            'updated_at'=>$date
            ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('status');
    }
}
