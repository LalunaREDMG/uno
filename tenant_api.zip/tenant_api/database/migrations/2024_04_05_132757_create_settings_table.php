<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        date_default_timezone_set('Asia/Manila');
        $date = date('Y-m-d h:i:s');

        Schema::create('settings', function (Blueprint $table) {
            $table->tinyInteger('id');
            $table->string('cccode');
            $table->tinyInteger('pos_vendor_code');
            $table->string('autopoll_ip_server');
            $table->tinyInteger('port');
            $table->timestamps();
        });
       
        DB::table('settings')->insert([
            'id'=>1,
            'cccode'=>'1234567890',
            'pos_vendor_code'=>1003,
            'autopoll_ip_server'=>'127.0.0.1',
            'port'=>443,
            'created_at'=>$date,
            'updated_at'=>$date
            ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
